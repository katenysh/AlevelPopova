package task2;

import java.util.Scanner;

public class Binary {
    public static void main (String[] args) {

        int a, x;
        Scanner s = new Scanner(System.in);

        System.out.print ("Введите число: ");
        int number = s.nextInt();

        if ( number <= 0 ) {
            System.out.println ("Недопустимое число");
        } else  {
            while (number!=0)

                if(number%2==0) {
                    number/=2;
                    System.out.print(0);
                }
                else if(number%2==1) {
                    number/=2;
                    System.out.print(1);
                }
                else if(number==2) {
                    number/=2;
                    System.out.println(1);
                }
        }
    }
}
